const { createProxyMiddleware } = require('http-proxy-middleware');

module.exports = function (app) {
    app.use(
        '/api',
        createProxyMiddleware({
            target: 'http://localhost:8080',
            changeOrigin: true,
            secure: false,
            logLevel: 'debug',
            onProxyReq: (proxyReq, req, res) => {
                // Adicionar headers CORS se necess�rio
                proxyReq.setHeader('Access-Control-Allow-Origin', 'http://localhost:3000');
                proxyReq.setHeader('Access-Control-Allow-Methods', 'GET, PUT, POST, DELETE, OPTIONS');
                proxyReq.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
            }
        })
    );
};
