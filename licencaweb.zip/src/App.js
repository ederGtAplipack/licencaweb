import React from 'react';
import Routes from './Routers';

/*
  Componente principal da aplica��o.
  Renderiza o componente de rotas para gerenciar a navega��o entre p�ginas.
*/
function App() {
    return (
        <Routes/>
    );
}

export default App;
