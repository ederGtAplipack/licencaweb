import React from 'react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { TextField, Button, Container, Typography, Box } from '@mui/material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { toast } from 'react-toastify';

const schema = yup.object().shape({
    nome: yup.string().required('Nome is required'),
    validade: yup.date().required('Validade is required').nullable(),
});

const NewLicenca = () => {
    const navigate = useNavigate();
    const {
        register,
        handleSubmit,
        setValue,
        formState: { errors },
    } = useForm({
        resolver: yupResolver(schema),
    });
    const onSubmit = async (data) => {
        try {
            await axios.post('/api/licencas', data);
            toast.success('Licen�a created successfully');
            navigate('/licencas');
        } catch (error) {
            toast.error('Failed to create Licen�a');
        }
    };
    return (
        <Container maxWidth="sm">
            <Typography variant="h4" component="h1" gutterBottom>
                New Licen�a
            </Typography>
            <Box component="form" onSubmit={handleSubmit(onSubmit)} noValidate sx={{ mt: 1 }}>
                <TextField
                    margin="normal"
                    fullWidth
                    label="Nome"
                    {...register('nome')}
                    error={!!errors.nome}
                    helperText={errors.nome?.message}
                />
                <DatePicker
                    label="Validade"
                    onChange={(date) => setValue('validade', date)}
                    renderInput={(params) => (
                        <TextField
                            {...params}
                            margin="normal"
                            fullWidth
                            error={!!errors.validade}
                            helperText={errors.validade?.message}
                        />
                    )}
                />
                <Button type="submit" fullWidth variant="contained" sx={{ mt: 3, mb: 2 }}>
                    Create Licen�a
                </Button>
            </Box>
        </Container>
    );
}
export default NewLicenca;
