﻿// src/pages/Dashboard/Dashboard.js
import { useState, useEffect } from "react";
import api from "../../services/api"; // caso use a LicencaAPI
import "../../style.css"; // Certifique-se de que o Tailwind CSS está importado

function Dashboard() {
    const [licencas, setLicencas] = useState([]);
    const [filtro, setFiltro] = useState("");

    // exemplo de busca de licenças via API
    useEffect(() => {
        async function fetchLicencas() {
            try {
                const { data } = await api.get("/licencas"); // ajuste sua rota
                setLicencas(data);
            } catch (err) {
                console.error("Erro ao carregar licenças", err);
            }
        }
        fetchLicencas();
    }, []);

    // Filtragem das licenças
    const licencasFiltradas = licencas.filter((l) =>
        [l.cliente, l.mac, l.ip].some((campo) =>
            campo.toLowerCase().includes(filtro.toLowerCase())
        )
    );

    return (
        <div className="container">
            {/* Sidebar */}
            <aside className="sidebar">
                <div className="logo">
                    <img src="../img/Aplipack_Software.png" alt="Logo Aplipack" width="100%" />                    
                </div>
                <nav>
                    <ul>
                        <li>
                            <a href="#" className="active">
                                Home
                            </a>
                        </li>
                        <li>
                            <a href="/nova-licenca">Nova Licença</a>
                        </li>
                    </ul>
                </nav>
            </aside>

            {/* Conteúdo Principal */}
            <div className="main">
                {/* Topbar */}
                <header className="topbar">
                    <div className="title">Sistema de Licenças - Aplipack Software</div>
                    <div className="user-info">
                        <span>eder.silva@aplipack.com.br</span> | <a href="#">Logout</a>
                        <div className="timezone">All times are UTC-03:00</div>
                    </div>
                </header>

                {/* Conteúdo */}
                <main>
                    <section className="card-section">
                        <div className="card">
                            <input
                                type="text"
                                placeholder="🔍 Buscar por cliente, MAC ou IP..."
                                style={{
                                    width: "-webkit-fill-available",
                                    padding: "12px",
                                    marginBottom: "20px",
                                    borderRadius: "6px",
                                    border: "1px solid #ccc",
                                }}
                                value={filtro}
                                onChange={(e) => setFiltro(e.target.value)}
                            />
                            <strong>Total de Licenças Ativas:</strong>{" "}
                            <span>{licencasFiltradas.length}</span>

                            <table className="session-table">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Cliente</th>
                                        <th>MAC</th>
                                        <th>Software</th>
                                        <th>IP</th>
                                        <th>Data de Ativação</th>
                                        <th>Validade</th>
                                        <th>Status</th>
                                        <th>Ações</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {licencasFiltradas.map((l) => (
                                        <tr key={l.id}>
                                            <td>{l.id}</td>
                                            <td>{l.cliente}</td>
                                            <td>{l.mac}</td>
                                            <td>{l.software}</td>
                                            <td>{l.ip}</td>
                                            <td>{l.dataAtivacao}</td>
                                            <td>{l.validade}</td>
                                            <td>{l.status}</td>
                                            <td>
                                                <button>Editar</button>
                                                <button>Excluir</button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>

                        <div className="card">
                            <canvas id="graficoSoftware" width="600" height="280"></canvas>
                        </div>
                    </section>
                </main>
            </div>
        </div>
    );
}

export default Dashboard;
